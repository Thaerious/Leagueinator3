﻿
namespace Leagueinator.GUI.Controllers.DragDropManager {
    public interface IDragDrop {
        public void DoDrop(object dragSource);
    }
}

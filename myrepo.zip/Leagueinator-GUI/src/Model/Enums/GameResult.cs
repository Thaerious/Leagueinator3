﻿namespace Leagueinator.GUI.Model.Enums {
    public enum GameResult {
        Vacant = 0,
        Loss = 1,
        Draw = 2,
        Win = 3,
    }
}

﻿namespace Leagueinator.GUI.Controls.MatchCards {
    public partial class MatchCardV4 : MatchCard {
        public MatchCardV4() : base() {
            this.InitializeComponent();
        }
    }
}

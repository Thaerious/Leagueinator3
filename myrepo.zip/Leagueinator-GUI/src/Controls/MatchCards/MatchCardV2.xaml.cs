﻿
namespace Leagueinator.GUI.Controls.MatchCards {
    public partial class MatchCardV2 : MatchCard {
        public MatchCardV2() : base() {
            this.InitializeComponent();
        }
    }
}

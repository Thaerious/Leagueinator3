﻿namespace Leagueinator.GUI.Controls.MatchCards {
    public partial class MatchCardV3 : MatchCard {
        public MatchCardV3() : base() {
            this.InitializeComponent();
        }
    }
}

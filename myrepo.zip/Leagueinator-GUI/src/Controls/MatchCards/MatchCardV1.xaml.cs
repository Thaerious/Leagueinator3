﻿namespace Leagueinator.GUI.Controls.MatchCards {
    public partial class MatchCardV1 : MatchCard {
        public MatchCardV1() : base() {
            this.InitializeComponent();
        }
    }
}
